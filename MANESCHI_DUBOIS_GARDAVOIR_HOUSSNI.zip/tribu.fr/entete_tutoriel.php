<!-- Sandre : 11/05/2015 -->
<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Tribu - Tutoriel</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" href="images/favicon.ico"/>
  </head>
  <body>
		<div id="main-container">
      <a href="./accueil.php">
			     <img id="logo" src="images/Logo_white.png">
      </a>
			<nav>
        <ul>
          <li class="menu_tutoriel"><a href="./accueil.php">Accueil</a></li><!--
          --><li class="menu_tutoriel"><a href="./choix_salle.php">Jouer</a></li><!--
          --><li class="menu_tutoriel"><a href="./tutoriel.php">Tutoriel</a></li><!--
          --><li class="menu_tutoriel"><a href="./classement.php">Classement</a></li><!--
          --><li class="menu_tutoriel"><a href="./profil.php">Mon Compte</a></li>
        </ul>
			</nav>
