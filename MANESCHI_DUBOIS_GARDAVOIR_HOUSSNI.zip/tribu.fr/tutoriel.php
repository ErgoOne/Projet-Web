<?php include('entete_tutoriel.php'); ?>
			<div id="tutoriel-container">
				<h1>Gestion deplacement et bateaux</h1>
				<div id="video-tutoriel-container">
					<iframe width="430px" height="290px" src="https://www.youtube.com/embed/ytWz0qVvBZ0" frameborder="0" allowfullscreen></iframe>
				</div>
				<div id="text-right-tutoriel-container">
					<p>Pour jouer, rien de plus simple ! Commencer par sélectionner un bateau en double cliquant dessus, puis rentrer les coordonnées de la case de destination dans les menus déroulants et enfin cliquer sur "Déplacer".
                    </p>				
                </div>
			</div>
<!--
			<div id="tutoriel-container">
				<h1>Gestion Argent</h1>
				<div id="text-left-tutoriel-container">
					<p>Pour jouer, rien de plus simple ! Commencer par sélectionner un bateau en double cliquant dessus, puis rentrer les coordonnées de la case de destination dans les menus déroulants et enfin cliquer sur "Déplacer".
                    <br></p>
				</div>
				<div id="video-tutoriel-container">
					<iframe width="430px" height="290px" src="https://www.youtube.com/embed/ytWz0qVvBZ0" frameborder="0" allowfullscreen></iframe>
				</div>
			</div>
-->
		</div>
  </body>
<?php include('footer.php'); ?>
</html>
