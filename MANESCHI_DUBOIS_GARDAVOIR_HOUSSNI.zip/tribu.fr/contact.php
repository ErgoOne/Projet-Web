<?php include('entete_accueil.php') ?>
        <div id="tutoriel-container">
                <h1>Contact</h1>
                <div id="div-left-contact">
                    <h2>Projet</h2>
                    <p>Jeu réalisé dans le cadre du projet Web de Licence 3 STRI.</p>
                    <img style="margin-left:26%;" height="60" src="images/upslogo.png" alt="Logo UPS"/>
                    <img style="margin-left:30%;" height="80" src="images/strilogo.png" alt="Logo STRI"/>
                </div>
                <div id="div-right-contact">
                    <h2>Mail</h2>
                    <p>Pour toutes questions, n'hésitez pas à contacter les membres de l'équipe via les liens ci-dessous :</p>
                    <li><a href="mailto:stephanie.maneschi@hotmail.fr?subject=Jeu Tribu - Questions/Remarques">Mme MANESCHI</a></li>
                    <li><a href="mailto:hou.badr@gmail.com?subject=Jeu Tribu - Questions/Remarques">Mr HOUSSNI</a></li>
                    <li><a href="mailto:gardavoiralexis@gmail.com?subject=Jeu Tribu - Questions/Remarques">Mr GARDAVOIR</a></li>
                    <li><a href="mailto:sandre.dubois@hotmail.fr?subject=Jeu Tribu - Questions/Remarques">Mr DUBOIS</a></li>
                </div>
        </div>
    </div>
  </body>
<?php include('footer.php'); ?>
</html>