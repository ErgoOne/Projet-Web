<!-- Sandre : 11/05/2015 -->
  <footer>
    <div><center><a href="./contact.php" style="text-decoration:none; color:white;">Tribu - © CopyLeft - Created by Maneschi / Houssni / Gardavoir / Dubois</a></center></div>
  </footer>
</html>
