<?php

	include("entete_choix_salle.php");

	echo("<h1>" . $_SESSION['email_adversaire'] . "</h1>");

?>